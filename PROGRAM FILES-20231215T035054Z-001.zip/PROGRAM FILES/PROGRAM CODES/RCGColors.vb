﻿Public Structure RCGColors
    Public Shared Color1 As Color = Color.FromArgb(112, 128, 144)
    Public Shared Color2 As Color = Color.FromArgb(176, 196, 222)
    Public Shared Color3 As Color = Color.FromArgb(245, 255, 250)
    Public Shared Color4 As Color = Color.FromArgb(240, 248, 255)
    Public Shared Color5 As Color = Color.FromArgb(255, 239, 213)
    Public Shared Color6 As Color = Color.FromArgb(240, 255, 240)
End Structure
